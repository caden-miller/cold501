var n={};Object.defineProperty(n,"__esModule",{value:true});n.warning=function(){};n.invariant=function(){};const e=n.__esModule,t=n.warning,r=n.invariant;export default n;export{e as __esModule,r as invariant,t as warning};

