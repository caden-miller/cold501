class MotionValue{setAnimation(i){this.animation=i;i===null||i===void 0?void 0:i.finished.then((()=>this.clearAnimation())).catch((()=>{}))}clearAnimation(){this.animation=this.generator=void 0}}export{MotionValue};

