// Import and register all your controllers from the importmap via controllers/**/*_controller
import { application } from "./application"
import controllers from "./**/*_controller.js";
