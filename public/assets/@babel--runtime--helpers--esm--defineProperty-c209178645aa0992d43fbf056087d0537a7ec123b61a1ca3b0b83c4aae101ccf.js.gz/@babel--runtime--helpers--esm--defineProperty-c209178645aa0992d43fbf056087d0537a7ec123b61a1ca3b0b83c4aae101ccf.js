import e from"./toPropertyKey.js";import"./typeof.js";import"./toPrimitive.js";function _defineProperty(r,t,o){return(t=e(t))in r?Object.defineProperty(r,t,{value:o,enumerable:!0,configurable:!0,writable:!0}):r[t]=o,r}export{_defineProperty as default};

